var limit = 1;
var navInfo = null;

const init = async()=>{
     await initNavigation(0);
}

const initNavigation = async id => {
     const navInfoUrl = `https://pokeapi.co/api/v2/pokemon?offset=${id}&limit=1`;
     const navRest = await fetch(navInfoUrl);
     navInfo = await navRest.json();
     limit = navInfo.count;
     var pokeUrl = navInfo.results[0].url;
     await getPok(pokeUrl);
}


const navigate = async(url) => {
     
     const navRest = await fetch(url);
     navInfo = await navRest.json();
     limit = navInfo.count;
     var pokeUrl = navInfo.results[0].url;
     await getPok(pokeUrl);
}

const getPok = async url => {
     
     const rest = await fetch(url);
     const pok = await rest.json();
     console.log(pok)
     doPok(pok);
    
}

function doPok(pok){
     var cardElement = $('.cards');

     cardElement.attr("href",`/pokemon/${pok.id}`);
     
     
     var pokeImageElement = cardElement.find('.card-pokemon_image');
     var pokeNameElement = cardElement.find('.card-pokemon_name');

     pokeNameElement.text(pok.name)
     pokeImageElement.attr('src', pok.sprites.other.home.front_default);
}

async function next()
{
    
     if(navInfo.next == null)
     {  
          await initNavigation(0)

     }else{
          await navigate(navInfo.next);
     }
  
}

async function prev()
{
   
     if(navInfo.previous == null)
     {
          await initNavigation(limit-1);
     }else{
          await navigate(navInfo.previous);
     }
     
}

init();
