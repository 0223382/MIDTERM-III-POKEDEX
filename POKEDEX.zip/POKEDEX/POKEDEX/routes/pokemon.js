var express = require('express');
var request = require('request');
var router = express.Router();

/* GET home page. */
router.get('/:id', async function(req, res, next) {
  var id = req.params.id;
  var url = `https://pokeapi.co/api/v2/pokemon/${id}`;
  request(url, function(err, response){
    var pok = JSON.parse(response.body);
    res.render('pokemon', {pok: pok});
  });
});

module.exports = router;
