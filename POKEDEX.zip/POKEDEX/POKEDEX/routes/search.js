var express = require('express');
var request = require('request');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
    var searchText = req.query.searchText;
    var url = `https://pokeapi.co/api/v2/pokemon/${searchText}`;
    request(url, function(err, response){
        console.error(response);
        if(err)
        {
            res.render('search', {pok: null, searchText: searchText});
        }

        if(response.statusCode == 200)
        {
            var pok = JSON.parse(response.body);
            return res.render('search', {pok: pok, searchText: searchText});
        }

      res.render('search', {pok: null, searchText: searchText});
    });
});

module.exports = router;
